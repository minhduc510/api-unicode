<h1 class="text-center">Tài liệu API</h1>
<p class="text-center">Tài liệu này mô tả các endpoint của API cho ứng dụng.</p>
<?php /**PATH C:\Users\MinhDuc\Desktop\api-unicode\resources\views/layouts/header.blade.php ENDPATH**/ ?>