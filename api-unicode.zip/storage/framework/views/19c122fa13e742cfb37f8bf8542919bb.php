<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tài liệu API</title>
    <!-- Thêm Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        pre {
            background-color: #f8f9fa;
            padding: 10px;
            border-radius: 5px;
        }

        .nav-pills .nav-link.active {
            background-color: #007bff;
        }

        .fixed-menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #f8f9fa;
            padding-top: 20px;
        }

        .content {
            margin-left: 270px;
        }
    </style>
</head>

<body>
    <div class="fixed-menu">
        <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <li class="nav-item">
                <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab"
                    aria-controls="v-pills-home" aria-selected="true">Tổng quan</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="v-pills-login-tab" data-toggle="pill" href="#v-pills-login" role="tab"
                    aria-controls="v-pills-login" aria-selected="false">Đăng nhập</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="v-pills-register-tab" data-toggle="pill" href="#v-pills-register" role="tab"
                    aria-controls="v-pills-register" aria-selected="false">Đăng ký</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="v-pills-profile-tab" data-toggle="pill" href="#v-pills-profile" role="tab"
                    aria-controls="v-pills-profile" aria-selected="false">Profile</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="v-pills-refresh-tab" data-toggle="pill" href="#v-pills-refresh" role="tab"
                    aria-controls="v-pills-refresh" aria-selected="false">Refresh Token</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="v-pills-logout-tab" data-toggle="pill" href="#v-pills-logout" role="tab"
                    aria-controls="v-pills-logout" aria-selected="false">Đăng xuất</a>
            </li>
        </ul>
    </div>

    <div class="container content mt-5">
        <h1 class="text-center">Tài liệu API</h1>
        <p class="text-center">Tài liệu này mô tả các endpoint của API cho ứng dụng.</p>

        <div class="tab-content" id="v-pills-tabContent">
            <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
                <h2 class="mt-5">Base URL</h2>
                <pre><code>https://reactjs-api-unicode.online/api</code></pre>
            </div>

            <div class="tab-pane fade" id="v-pills-login" role="tabpanel" aria-labelledby="v-pills-login-tab">
                <h2 class="mt-5">1. Đăng nhập</h2>
                <p><strong>Phương thức:</strong> <code>POST</code></p>
                <p><strong>Endpoint:</strong> <code>/auth/login</code></p>
                <p><strong>Mô tả:</strong> Đăng nhập với email và password.</p>
                <p><strong>Tham số:</strong></p>
                <ul>
                    <li><code>email</code> (string, bắt buộc): Email.</li>
                    <li><code>password</code> (string, bắt buộc): Mật khẩu.</li>
                </ul>
                <h4>Body:</h4>
                <pre><code>{
    "email": "unicode@gmail.com",
    "password": "unicode"
}</code></pre>
                <h4>Response:</h4>
                <pre><code>{
    "status": "success",
    "access_token": "eyJ0eXAi...",
    "refresh_token": "eyJ0eXAi...",
    "token_type": "bearer"
}</code></pre>
            </div>

            <div class="tab-pane fade" id="v-pills-register" role="tabpanel" aria-labelledby="v-pills-register-tab">
                <h2 class="mt-5">2. Đăng ký</h2>
                <p><strong>Phương thức:</strong> <code>POST</code></p>
                <p><strong>Endpoint:</strong> <code>/auth/register</code></p>
                <p><strong>Mô tả:</strong> Đăng ký tài khoản.</p>
                <p><strong>Tham số:</strong></p>
                <ul>
                    <li><code>name</code> (string, bắt buộc): Tên.</li>
                    <li><code>email</code> (string, bắt buộc): Email.</li>
                    <li><code>password</code> (string, bắt buộc): Mật khẩu.</li>
                    <li><code>password_confirmation</code> (string, bắt buộc): Xác nhận mật khẩu.</li>
                </ul>
                <h4>Body:</h4>
                <pre><code>{
    "name": "Unicode Academy",
    "email": "unicode@gmail.com",
    "password": "unicode",
    "password_confirmation": "unicode"
}</code></pre>
            </div>

            <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                <h2 class="mt-5">3. Lấy thông tin profile</h2>
                <p><strong>Phương thức:</strong> <code>GET</code></p>
                <p><strong>Endpoint:</strong> <code>/auth/profile</code></p>
                <p><strong>Mô tả:</strong> Lấy thông tin profile của người dùng.</p>
                <h4>Header:</h4>
                <pre><code>Authorization: Bearer {your_token}</code></pre>
            </div>

            <div class="tab-pane fade" id="v-pills-refresh" role="tabpanel" aria-labelledby="v-pills-refresh-tab">
                <h2 class="mt-5">4. Refresh Token</h2>
                <p><strong>Phương thức:</strong> <code>POST</code></p>
                <p><strong>Endpoint:</strong> <code>/auth/refresh</code></p>
                <p><strong>Mô tả:</strong> Cấp lại Access Token và Refresh Token mới.</p>
                <h4>Body:</h4>
                <pre><code>{
    "refresh_token": {your_token}
}</code></pre>
            </div>

            <div class="tab-pane fade" id="v-pills-logout" role="tabpanel" aria-labelledby="v-pills-logout-tab">
                <h2 class="mt-5">5. Đăng xuất</h2>
                <p><strong>Phương thức:</strong> <code>POST</code></p>
                <p><strong>Endpoint:</strong> <code>/auth/logout</code></p>
                <h4>Header:</h4>
                <pre><code>Authorization: Bearer {your_token}</code></pre>
            </div>
        </div>
    </div>

    <!-- Thêm Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH C:\Users\MinhDuc\Desktop\api-unicode\resources\views/welcome.blade.php ENDPATH**/ ?>