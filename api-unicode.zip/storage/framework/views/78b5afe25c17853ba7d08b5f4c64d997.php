<div class="fixed-menu">
    <ul class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
        <li class="nav-item">
            <a class="nav-link active" id="v-pills-home-tab" data-toggle="pill" href="#v-pills-home" role="tab"
                aria-controls="v-pills-home" aria-selected="true">Tổng quan</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="v-pills-auth-tab" data-toggle="pill" href="#v-pills-auth" role="tab"
                aria-controls="v-pills-auth" aria-selected="false">Auth</a>
        </li>

    </ul>
</div>
<?php /**PATH C:\Users\MinhDuc\Desktop\api-unicode\resources\views/layouts/menu.blade.php ENDPATH**/ ?>