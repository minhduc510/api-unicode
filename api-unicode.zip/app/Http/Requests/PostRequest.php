<?php

namespace App\Http\Requests;

use App\Helpers\ResponseHelper;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Validation\ValidationException;

class PostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'content' => 'required|string',

            'images' => 'array',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif|max:2048',

            'videos' => 'array',
            'videos.*' => 'mimetypes:video/avi,video/mp4,video/mpeg,video/quicktime|max:10240',
        ];
    }

    // public function messages(): array
    // {
    //     return [
    //         [
    //             'images.*.image' => 'File ảnh không hợp lệ.',
    //             'images.*.mimes' => 'Ảnh phải có định dạng: jpeg, png, jpg, gif.',
    //             'images.*.max' => 'Dung lượng ảnh không được vượt quá 2MB.',
    //             'videos.*.mimetypes' => 'Video phải có định dạng: avi, mp4, mpeg, hoặc quicktime.',
    //             'videos.*.max' => 'Dung lượng video không được vượt quá 10MB.',
    //         ]
    //     ];
    // }

    protected function failedValidation(Validator $validator)
    {
        $errors = $validator->errors();
        throw (new ValidationException($validator, ResponseHelper::error('Validation error', $errors->toArray(), 422)))
            ->status(422);
    }
}
