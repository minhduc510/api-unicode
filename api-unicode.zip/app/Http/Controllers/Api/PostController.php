<?php

namespace App\Http\Controllers\Api;

use App\Models\Post;
use App\Helpers\FileHelper;
use Illuminate\Http\Request;
use App\Helpers\ResponseHelper;
use App\Helpers\TransactionHelper;
use App\Http\Requests\PostRequest;
use App\Http\Controllers\Controller;

class PostController extends Controller
{
    protected $postModel;

    public function __construct(Post $post)
    {
        $this->postModel = $post;
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $posts = $this->postModel->with('user', 'images', 'videos')->get();
        $dataRes = [];
        foreach ($posts as $post) {
            $images = [];
            if (count($post->images) > 0) {
                foreach ($post->images as $image) {
                    $images[] = [
                        'id' => $image->id,
                        'name' => $image->name,
                        'path' => env('APP_URL') . $image->path,
                        'size' => $image->size,
                    ];
                }
            }

            $videos = [];
            if (count($post->videos) > 0) {
                foreach ($post->videos as $video) {
                    $videos[] = [
                        'id' => $video->id,
                        'name' => $video->name,
                        'path' => env('APP_URL') . $video->path,
                        'size' => $video->size,
                    ];
                }
            }

            $dataRes[] = [
                'id' => $post->id,
                'content' => $post->content,
                'user' => [
                    'id' => $post->user->id,
                    'name' => $post->user->name,
                    'email' => $post->user->email,
                    'avatar_path' => env('APP_URL') . $post->user->avatar_path,
                ],
                'images' => $images,
                'videos' => $videos
            ];
        }

        return ResponseHelper::success('Retrieve all posts successfully!', $dataRes, 200);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(PostRequest $request)
    {
        TransactionHelper::handle(function () use ($request) {

            $user = json_decode($request->header('user'));

            $data = [
                'user_id' => $user->id,
                'content' => $request->content
            ];

            $post = $this->postModel->create($data);

            if ($request->has('images')) {
                $dataImages = [];
                foreach ($request->images as $image) {
                    $fileInfo = FileHelper::uploadFile($image, 'posts/images');
                    if (!is_null($fileInfo)) {
                        $dataImages[] = [
                            'name' => $fileInfo['filename'],
                            'path' => $fileInfo['path'],
                            'size' => $fileInfo['size']
                        ];
                    }
                }

                $post->images()->createMany($dataImages);
            }

            if ($request->has('videos')) {
                $dataVideos = [];
                foreach ($request->videos as $video) {
                    $fileInfo = FileHelper::uploadFile($video, 'posts/videos');
                    if (!is_null($fileInfo)) {
                        $dataVideos[] = [
                            'name' => $fileInfo['filename'],
                            'path' => $fileInfo['path'],
                            'size' => $fileInfo['size'],
                            'durations' => $fileInfo['duration'],
                            'post_id' => $post->id
                        ];
                    }
                }

                $post->videos()->createMany($dataVideos);

                return $post;
            }
        });

        return ResponseHelper::success('Post published successfully.', null, 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
