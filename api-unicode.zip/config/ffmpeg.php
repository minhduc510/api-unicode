<?php

return [
    'ffmpeg.binaries' => '/usr/bin/ffmpeg', // Đường dẫn đến ffmpeg
    'ffprobe.binaries' => '/usr/bin/ffprobe', // Đường dẫn đến ffprobe
    'timeout' => 3600,
    'ffmpeg.threads' => 12,
];
